from ..synthesis.beam_search import BeamSearcher
from ..dsl.executor import execute
from ..core.grid import grid_hash
from ..neural.ranker import load_ranker

class NeuroSymbolicARCSolver:
    """
    ARC solver interface.

    Input:
        train_pairs = [(input_grid, output_grid), ...]
        test_inputs = [input_grid, ...]

    Output:
        predictions = [
            [attempt_1_grid, attempt_2_grid],
            ...
        ]
    """

    def __init__(self, beam_width=100, max_depth=3, ranker=None, ranker_weights=None):
        self.searcher = BeamSearcher(beam_width, max_depth)
        self.ranker = ranker if ranker is not None else load_ranker(ranker_weights)

    def solve_task(self, train_pairs, test_inputs):
        programs, _beam = self.searcher.search(train_pairs, ranker=self.ranker)
        predictions = []

        for test_grid in test_inputs:
            groups = {}

            for candidate in programs:
                output = execute(candidate.program, test_grid)
                if output is None:
                    continue

                groups.setdefault(grid_hash(output), []).append(
                    (candidate, output)
                )

            ranked_groups = sorted(
                groups.values(),
                key=lambda group: min(item[0].score for item in group),
            )

            choices = []
            for group in ranked_groups:
                best = min(group, key=lambda item: item[0].score)
                choices.append(best[1].astype(int).tolist())
                if len(choices) == 2:
                    break

            # ARC requires two attempts. If synthesis finds no candidate,
            # identity is a safe structural fallback.
            if not choices:
                identity = test_grid.astype(int).tolist()
                choices = [identity, identity]
            elif len(choices) == 1:
                choices.append(choices[0])

            predictions.append(choices)

        return predictions, programs
